import {
    init_search
} from './modules/search.js'


window.addEventListener("load", () => {
    console.log("Init list template")

})